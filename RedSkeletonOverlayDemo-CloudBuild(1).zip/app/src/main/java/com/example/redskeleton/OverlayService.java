package com.example.redskeleton;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class OverlayService extends Service {
    WindowManager wm;
    View panel;
    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        panel = new SkeletonView();
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            320, 360, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = 30; p.y = 140;
        wm.addView(panel, p);
    }
    @Override public int onStartCommand(Intent i, int f, int id) { return START_STICKY; }
    @Override public void onDestroy() { if (panel != null) wm.removeView(panel); super.onDestroy(); }
    @Override public IBinder onBind(Intent i) { return null; }

    class SkeletonView extends View {
        Paint paint = new Paint(3);
        SkeletonView() { super(OverlayService.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        void line(Canvas c, float x1,float y1,float x2,float y2) { c.drawLine(x1,y1,x2,y2,paint); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(Color.argb(65,0,0,0));
            paint.setColor(Color.WHITE); paint.setTextSize(17); paint.setStrokeWidth(2);
            c.drawText("RED SKELETON · DEMO", 12, 24, paint);
            paint.setColor(Color.RED); paint.setStrokeWidth(3);
            for (int k=0;k<3;k++) {
                float x=58+k*100, y=125+(k%2)*18;
                line(c,160,40,x,y-48);
                c.drawCircle(x,y-48,7,paint);
                line(c,x,y-41,x,y+2);
                line(c,x,y-25,x-17,y-5); line(c,x,y-25,x+17,y-5);
                line(c,x,y+2,x-14,y+34); line(c,x,y+2,x+14,y+34);
            }
            paint.setColor(Color.WHITE); paint.setTextSize(12);
            c.drawText("模拟目标  × 3", 12, 345, paint);
        }
    }
}
