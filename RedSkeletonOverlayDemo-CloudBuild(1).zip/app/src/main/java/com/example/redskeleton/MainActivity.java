package com.example.redskeleton;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 100;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 36, 28, 28);
        TextView title = new TextView(this);
        title.setText("红色人物骨骼 · 演示版");
        title.setTextSize(22);
        layout.addView(title);
        TextView info = new TextView(this);
        info.setText("仅绘制内置模拟人物，不读取其他应用或游戏数据。");
        info.setPadding(0, 20, 0, 24);
        layout.addView(info);
        Button start = new Button(this);
        start.setText("开启悬浮窗演示");
        layout.addView(start);
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, REQUEST_OVERLAY);
            } else startService(new Intent(this, OverlayService.class));
        });
        setContentView(layout);
    }
    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r,c,d);
        if (r == REQUEST_OVERLAY && Settings.canDrawOverlays(this))
            startService(new Intent(this, OverlayService.class));
    }
}
