# Red Skeleton Overlay Demo

独立 Android 演示项目。悬浮窗绘制内置模拟人物、红色骨骼线和射线；不读取其他应用或游戏数据。

## 云端构建
GitHub Actions 工作流位于 `.github/workflows/build-apk.yml`。上传项目文件到仓库后，打开 Actions，运行 **Build demo APK**，在运行结果的 Artifacts 下载 `RedSkeletonOverlayDemo-debug`。
